#ifndef READLINE_H_INCLUDE
#define READLINE_H_INCLUDE

#include <stdio.h>
#include <ctype.h>

int read_line(char str[], int n);

#endif
