#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "request.h"

#define ROOM_LEN 100
#define NAME_LEN 30
#define PHONE_LEN 15

//function to append a new request to the list
struct request *append_to_list(struct request *list){
    struct request *child = malloc(sizeof(struct request));
    struct request *head, *previous;
    if (!(child)) { err("Failed to allocate memory in append_to_list()"); }

    //getting new request details
    printf("Enter child's classroom: ");
    read_line(child->classroom, ROOM_LEN);

    printf("Enter child's first name: ");
    read_line(child->first, NAME_LEN);

    printf("Enter child's last name : ");
    read_line(child->last, NAME_LEN);

    // looping through the list and looking for duplicate
    head = list;
    while (head != NULL) {
        // checking if the record already exists
        if (!(strcmp(head->classroom, child->classroom)) && !(strcmp(head->first, child->first)) && !(strcmp(head->last, child->last))) {
            printf("Oopsie, the record already exists. Please use update option\n");
            // deallocate memory and return list
            free(child);
            return list;
        }
        // go onto the next one
        head = head->next;
    }

    printf("Enter phone number : ");
    read_line(child->phone, PHONE_LEN);
    // setting next pointer of new request struct to NULL
    child->next = NULL;
    // if the current list is empty
    if (list == NULL) {
	return child;
    }

    // the magical loop that finds the right position to insert a node
    // firstly we check for the classroom and then for the last name
    // using strcmp() function that returns a negative value in case
    // the first argument is the first in the order before the second 
    // argument in the ASCII table
	for (head = list, previous = NULL; head != NULL &&
		(((strcmp(head->classroom, child->classroom) == 0 && strcmp(head->last, child->last) == 0 && strcmp(head->first, child->first) != 0)) ||
		((strcmp(head->classroom, child->classroom) == 0 &&  strcmp(head->last, child->last) < 0)) ||
		(strcmp(head->classroom, child->classroom) < 0)); previous = head, head = head->next);
    // now when we reached the position we need, we insert the node in the appropriate place
    child->next = head;
    // if this is the first element of the list
    if (previous == NULL) {
	list = child;
    } else {
	previous->next = child;
    }
    // return the original head of the list
    return list;
}

// a function to delete a request using class, first, last
struct request *delete_from_list(struct request *list) {
	char classroom[ROOM_LEN];
	char first[NAME_LEN + 1];
	char last[NAME_LEN + 1];
	// creating two request vars to iterate through the list 
	struct request *current, *previous;
	// asking for input from user to delete a request
	printf("Enter child's first name: ");
	read_line(first, NAME_LEN);

	printf("Enter child's last name: ");
	read_line(last, NAME_LEN);

	printf("Enter the classroom: ");
	read_line(classroom, ROOM_LEN);
	// looping through
	for (current = list, previous = NULL;
	     current != NULL && strcmp(current->classroom, classroom) != 0  && strcmp(current->first, first) != 0 && strcmp(current->last, last) != 0;
	     previous = current, current = current->next) ;
	// if the linked list is empty
	if (current == NULL) {
		printf("Oopsie, the child's record was not found. Try again with different credentials.\n");
		return list;		
	}

	// if it is the first node
	if (previous == NULL) {
		list = list->next;
	// the node was found
	} else {
		previous->next = current->next;
	}
	printf("Record has been deleted successfully\n");
	free(current);
	return(list);

}

//function to update a child details
void update(struct request *list) {
    char classroom[ROOM_LEN];
    char first[NAME_LEN + 1];
    char last[NAME_LEN + 1];
    struct request *head;

    // check for dynamic allocation?
    // this doesn't work and I don't know why
    // struct request *head = malloc(sizeof(struct request *))

    //if the queue is empty
    if (list == NULL) { printf("The list is empty\n"); return; }

    printf("Enter the classroom: ");
    read_line(classroom, ROOM_LEN);

    printf("Enter child's first name: ");
    read_line(first, NAME_LEN);

    printf("Enter child's last name : ");
    read_line(last, NAME_LEN);

    head = list;
    while (head != NULL) {
        // if the info entered is in the list
        if (!(strcmp(head->classroom, classroom)) && !(strcmp(head->first, first)) && !(strcmp(head->last, last))) {
            printf("Enter the new class room: ");
            read_line(head->classroom, ROOM_LEN);
            // exiting the function if the record is found
            return;
        }
        head = head->next;
    }

    //child details not found
    printf("Oopsie, we couldn't find the info entered. Please check back in later\n");
}

//function to print the whole list
void printList(struct request *list) {
    printf("Classroom            First name           Last name            Phone\n");
    // looping through the list
    while (list != NULL) {
        // printing in format
        printf("%-20s %-20s %-20s %-20s\n", list->classroom, list->first, list->last, list->phone);
        list = list->next;
    }
}

void clearList(struct request *list) {
    struct request *next = NULL;
    while (list != NULL) {
        next = list->next;
        // deallocating the node and skipping to the next one
        free(list);
        list = next;
    }
}

// function for error exit
void err(char *message) {
    puts(message);
    exit(1);
}
